Python 3.10 must be installed! (NOT HIGHER!)
Internet connection must be available!
Disable your antivirus/defender as it might delete some important files !

Run "Builder.bat"